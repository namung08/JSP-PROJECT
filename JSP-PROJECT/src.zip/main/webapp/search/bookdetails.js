/**
 * 
 */

 // URL에서 책 정보를 추출합니다.
const urlParams = new URLSearchParams(window.location.search);
const isbn = urlParams.get('isbn');
const description = urlParams.get('description');
const imageSrc = urlParams.get('imageSrc');
const title = urlParams.get('title');
const author = urlParams.get('author');
const publisher = urlParams.get('publisher');
const discount = urlParams.get('discount');
const pubdate = urlParams.get('pubdate');


// 책 정보를 HTML로 구성합니다.
const bookDetailsHTML = `
    <div class="book-detail">
        <img src="${imageSrc}" alt="${title} cover">
        <h2>${title}</h2>
        <p><strong>Author:</strong> ${author}</p>
        <p><strong>Publisher:</strong> ${publisher}</p>
        <p><strong>Description:</strong> ${description}</p>
        <p><strong>Discount Price:</strong> ${discount}</p>
        <p><strong>Publication Date:</strong> ${pubdate}</p>
    </div>
`;

// 책 정보를 페이지에 삽입합니다.
document.getElementById('bookDetails').innerHTML = bookDetailsHTML;